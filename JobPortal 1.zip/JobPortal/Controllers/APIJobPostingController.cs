﻿using JobPortal.Data;
using JobPortal.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace JobPortal.Controllers
{
    [Route("api/JobPosting")]
    [ApiController]
    public class APIJobPostingController : ControllerBase
    {
        private ApplicationDbContext _context;

        public APIJobPostingController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("GetAll")]
        public IActionResult GetAll()
        {
            var allJobs = _context.JobPostings.ToArray();
            return Ok(allJobs);
        }

        [HttpGet("GetById")]
        public IActionResult GetById(int id)
        {
            var job = _context.JobPostings.SingleOrDefault(x => x.Id == id);
            return Ok(job);
        }

        [HttpPost("Create")]
        public IActionResult Create(JobPosting jobPosting)
        {            
            _context.JobPostings.Add(jobPosting);
            _context.SaveChanges();
            return Ok("Wurde hinzugefügt!");            
        }

        [HttpPut("Edit")]
        public IActionResult Edit(JobPosting newJob)
        {
            var oldJob = _context.JobPostings.SingleOrDefault(x => x.Id == newJob.Id);
            if(oldJob is null)
            {
                return NotFound("Job not found!");
            }

            oldJob.Id = newJob.Id;
            oldJob.JobTitle = newJob.JobTitle;
            oldJob.JobDescription = newJob.JobDescription;
            oldJob.JobLocation = newJob.JobLocation;
            oldJob.Salary = newJob.Salary;
            oldJob.StartDate = newJob.StartDate;
            oldJob.CompanyName = newJob.CompanyName;
            oldJob.CompanyImage = newJob.CompanyImage;
            oldJob.OwnerUsername = newJob.OwnerUsername;

            _context.Update(oldJob);
            _context.SaveChanges();

            return Ok("Wurde geändert!");
        }

        [HttpDelete("Delete")]
        public IActionResult Delete(int id)
        {
            if (id == 0)
            {
                return BadRequest();
            }
            var job = _context.JobPostings.SingleOrDefault(x => x.Id == id);
            if (job is null)
            {
                return NotFound();
            }
            _context.JobPostings.Remove(job);
            _context.SaveChanges();

            return Ok("Wurde gelöscht!");
        }
    }
}
