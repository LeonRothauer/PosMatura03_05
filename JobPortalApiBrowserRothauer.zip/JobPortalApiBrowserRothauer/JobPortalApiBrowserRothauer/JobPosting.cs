﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobPortalApiBrowserRothauer
{
    public class JobPosting
    {
        public int Id { get; set; }
        public string jobTitle { get; set; }
        public string jobLocation { get; set; }
        public string jobDescription { get; set; }
        public float salary { get; set; }
        public DateTime startDate { get; set; }
        public string? companyName { get; set; }
        public byte[] companyImage { get; set; }
        public string? ownerUsername { get; set; }
      
    }
}
