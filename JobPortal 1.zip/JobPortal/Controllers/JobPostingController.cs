﻿using Humanizer.Bytes;
using JobPortal.Data;
using JobPortal.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JobPortal.Controllers
{
    [Authorize]
    public class JobPostingController : Controller
    {
        private ApplicationDbContext _context;

        public JobPostingController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var jobPosting = _context.JobPostings.Where(x => x.OwnerUsername == User.Identity.Name).ToList();
            return View(jobPosting);
        }

        public IActionResult CreateEditJobPosting(int id)
        {
            if (id != 0)
            {
                var jobFromDb = _context.JobPostings.SingleOrDefault(x => x.Id == id);

                if (jobFromDb != null)
                {
                    if (jobFromDb.OwnerUsername != User?.Identity?.Name)
                    {
                        return Unauthorized();

                    }
                    return View(jobFromDb);
                }
                else
                {
                    return NotFound();
                }
            }

            return View();
        }

        public IActionResult CreateEditJob(JobPosting jobPosting, IFormFile file)
        {
            jobPosting.OwnerUsername = User.Identity.Name;

            if (file != null)
            {
                using (var ms = new MemoryStream())
                {
                    file.CopyTo(ms);
                    var bytes = ms.ToArray();
                    jobPosting.CompanyImage = bytes;
                }
            }
            else
            {
                using (var ms = new MemoryStream())
                {
                    FormFile f = new FormFile(ms, 0, 0, "file", "aadfas.png");
                    f.CopyTo(ms);
                    var bytes = ms.ToArray();
                    jobPosting.CompanyImage = bytes;
                }
                    
            }
            if (jobPosting.Id == 0)
            {
                _context.JobPostings.Add(jobPosting);
            }
            else
            {
                var jobFromDB = _context.JobPostings.SingleOrDefault(x => x.Id == jobPosting.Id);
                if (jobFromDB == null)
                {
                    return NotFound();
                }
                else
                {
                    jobFromDB.JobTitle = jobPosting.JobTitle;
                    jobFromDB.JobDescription = jobPosting.JobDescription;
                    jobFromDB.JobLocation = jobPosting.JobLocation;
                    jobFromDB.Salary = jobPosting.Salary;
                    jobFromDB.StartDate = jobPosting.StartDate;
                    jobFromDB.CompanyName = jobPosting.CompanyName;
                    jobFromDB.CompanyImage = jobPosting.CompanyImage;
                }
            }

            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        public IActionResult DeleteJobPosting(int id)
        {
            if (id == 0)
            {
                return BadRequest();
            }
            var jobPostingFromDb = _context.JobPostings.SingleOrDefault(x => x.Id == id);
            if(jobPostingFromDb is null)
            {
                return NotFound();
            }
            _context.JobPostings.Remove(jobPostingFromDb);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}
