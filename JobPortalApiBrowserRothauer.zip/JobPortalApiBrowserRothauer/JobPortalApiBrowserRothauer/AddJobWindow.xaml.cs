﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace JobPortalApiBrowserRothauer
{
    /// <summary>
    /// Interaktionslogik für AddJobWindow.xaml
    /// </summary>
    public partial class AddJobWindow : Window
    {
        private MainWindow previousWindow;
        public AddJobWindow(MainWindow previousWindow)
        {
            InitializeComponent();
            this.previousWindow = previousWindow;
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            Back();
        }
        
        private async void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                HttpClient client = new HttpClient();
                JobPosting newData = new JobPosting
                {
                    jobTitle = txtTitel.Text,
                    jobLocation = txtLocation.Text,
                    jobDescription = txtDescription.Text,
                    salary = float.Parse(txtSalary.Text),
                    startDate= txtDate.SelectedDate.Value,
                    companyName = txtName.Text,
                    companyImage = new byte[0],
                    ownerUsername = ""
                };

                var jsonInput = JsonConvert.SerializeObject(newData);
                var requestContent = new StringContent(jsonInput, Encoding.UTF8, "application/json");
                var httpResponse = await client.PostAsync("https://localhost:7037/api/jobposting/create", requestContent);
                if (httpResponse.IsSuccessStatusCode)
                {
                    MessageBox.Show("Job erfolgreich hinzugefügt!");
                    Back();
                }
                else
                {
                    MessageBox.Show("Fehler beim Hinzufügen des Jobs. Bitte versuchen Sie es erneut.");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SalaryNumberValidation(object sender, TextCompositionEventArgs e)
        {
            foreach (char c in e.Text)
            {
                if (!Char.IsDigit(c))
                {
                    e.Handled = true; 
                    return;
                }
            }
        }
        private void Back()
        {
                this.Hide();
                previousWindow.Show();
                previousWindow.LoadJobs();
        }

    }
}
