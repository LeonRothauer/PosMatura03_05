﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JobPortalApiBrowserRothauer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private JobPosting selectedJob;
        List<JobPosting> jobs = new List<JobPosting>();
        string baseApiUrl = "https://localhost:7037/api/jobposting";
        string baseApiUrlDel = "https://localhost:7037/api/jobposting/Delete?id=";

        public MainWindow()
        {
            InitializeComponent();
            CheckApiConnection();
            textReadOnly();
            btnAccept.Visibility = Visibility.Collapsed;
            btnBack.Visibility = Visibility.Collapsed;
            //LoadJobs();
        }     
        public void lstJobs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstJobs.SelectedItem != null)
            {
                JobPosting selectedJob = jobs.Find(n => n.jobTitle.StartsWith(lstJobs.SelectedItem.ToString()));
                if (selectedJob != null)
                {
                    txtTitel.Text = selectedJob.jobTitle;
                    txtDescription.Text = selectedJob.jobDescription;
                    txtName.Text = selectedJob.companyName;                
                    txtSalary.Text = selectedJob.salary.ToString();
                    txtLocation.Text = selectedJob.jobLocation;
                    txtDate.SelectedDate = selectedJob.startDate;

                }
            }
        }

        public async Task LoadJobs()
        {
            try
            {              
                    HttpClient client = new HttpClient();
                    HttpResponseMessage response = await client.GetAsync(baseApiUrl + "/GetAll");

                    // Überprüfen, ob die Anforderung erfolgreich war
                    response.EnsureSuccessStatusCode();

                    //Antwort deserialisieren 
                    string responseBody = await response.Content.ReadAsStringAsync();
                    jobs = JsonConvert.DeserializeObject<List<JobPosting>>(responseBody);

                    lstJobs.Items.Clear();
                    foreach (JobPosting item in jobs)
                    {
                        string shortTitle = item.jobTitle.Length > 20 ? item.jobTitle.Substring(0, 20) : item.jobTitle;
                        lstJobs.Items.Add(shortTitle);
                    }
                    lstJobs.SelectedIndex = 0;      
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public async void btnLoad_Click(object sender, RoutedEventArgs e)
        {  
                LoadJobs();

        }              
        private void btnNew_Click(object sender, RoutedEventArgs e)
        {
            AddJobWindow secondWindow = new AddJobWindow(this);
            secondWindow.Show();
            this.Hide();
        }
        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (lstJobs.SelectedItem != null)
            {
                selectedJob = jobs.Find(n => n.jobTitle.StartsWith(lstJobs.SelectedItem.ToString()));
                if (selectedJob != null)
                {
                    txtTitel.IsReadOnly = false;
                    txtDescription.IsReadOnly = false;
                    txtSalary.IsReadOnly = false;
                    txtName.IsReadOnly = false;
                    txtLocation.IsReadOnly = false;
                    txtDate.IsHitTestVisible = true;
                    btnAccept.Visibility = Visibility.Visible;
                    btnBack.Visibility = Visibility.Visible;
                    btnChange.Visibility = Visibility.Collapsed;
                    btnDelete.Visibility = Visibility.Collapsed;
                    btnLoad.Visibility = Visibility.Collapsed;
                    btnNew.Visibility = Visibility.Collapsed;
                    lstJobs.IsHitTestVisible = false;
                }
            }
        }

        private async void btnEditAccept_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                selectedJob.jobTitle = txtTitel.Text;
                selectedJob.jobDescription = txtDescription.Text;
                selectedJob.jobLocation = txtLocation.Text;
                selectedJob.salary = float.Parse(txtSalary.Text);
                selectedJob.startDate = txtDate.SelectedDate.Value;
                selectedJob.companyName = txtName.Text;
                selectedJob.companyImage = new byte[0];
                selectedJob.ownerUsername = "";

                string json = JsonConvert.SerializeObject(selectedJob);
                HttpClient client = new HttpClient();
                HttpResponseMessage response = await client.PutAsync("https://localhost:7037/api/JobPosting/Edit", new StringContent(json, Encoding.UTF8, "application/json"));

                response.EnsureSuccessStatusCode();

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("JobPosting erfolgreich geändert.");
                    LoadJobs();
                    lstJobs.IsHitTestVisible = true;
                }
                else
                {
                    MessageBox.Show("Fehler beim Hinzufügen des Jobs. Bitte versuchen Sie es erneut.");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private async void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                MessageBoxResult result = MessageBox.Show("Sind Sie sicher, dass Sie das Job Posting löschen wollen?", "Bestätigung", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    JobPosting selectedJob = jobs.Find(n => n.jobTitle.StartsWith(lstJobs.SelectedItem.ToString()));


                    if (selectedJob == null)
                    {
                        MessageBox.Show("Bitte wählen Sie eine Notiz aus, die gelöscht werden soll.");
                        return;
                    }
                    int jobId = selectedJob.Id;


                    HttpClient client = new HttpClient();
                    HttpResponseMessage response = await client.DeleteAsync($"{baseApiUrlDel}{jobId}");


                    response.EnsureSuccessStatusCode();

                    // gelöschten Job aus der Liste entfernen 
                    jobs.RemoveAll(n => n.Id == jobId);
                    LoadJobs();
    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            textReadOnly();
            btnAccept.Visibility = Visibility.Collapsed;
            btnBack.Visibility = Visibility.Collapsed;
            btnChange.Visibility = Visibility.Visible;
            btnDelete.Visibility = Visibility.Visible;
            btnLoad.Visibility = Visibility.Visible;
            btnNew.Visibility = Visibility.Visible;
            LoadJobs();
            lstJobs.IsHitTestVisible = true;
        }

        private void textReadOnly()
        {
            txtTitel.IsReadOnly = true;
            txtDescription.IsReadOnly = true;
            txtSalary.IsReadOnly = true;
            txtName.IsReadOnly = true;
            txtLocation.IsReadOnly = true;
            txtDate.IsHitTestVisible = false;
        }
        public async Task CheckApiConnection()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    HttpResponseMessage response = await client.GetAsync(baseApiUrl + "/GetAll");

                    response.EnsureSuccessStatusCode();
                 
                }
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void SalaryNumberValidation(object sender, TextCompositionEventArgs e)
        {
            foreach (char c in e.Text)
            {
                if (!Char.IsDigit(c))
                {
                    e.Handled = true;
                    return;
                }
            }
        }
    }
}
